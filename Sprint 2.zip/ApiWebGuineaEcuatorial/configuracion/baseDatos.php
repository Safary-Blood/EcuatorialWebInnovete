<?php
class BaseDatos {
    private $host = "localhost";
    private $dbNombre = "apiwebofertaempleoguineaecuatorial";
    private $usuario = "root";
    private $contrasena = "";
    public $conexion;

    public function obtenerConexion() {
        $this->conexion = null;
        try {
            $this->conexion = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbNombre, $this->usuario, $this->contrasena);
            $this->conexion->exec("set names utf8");
        } catch(PDOException $excepcion) {
            echo "Error de conexión: " . $excepcion->getMessage();
        }
        return $this->conexion;
    }
}

