<script src="../js/jquery.min.js"></script>
<script src="../js/sweetalert2.js"></script>
<script src="../js/ajaxFormularios.js"></script>
