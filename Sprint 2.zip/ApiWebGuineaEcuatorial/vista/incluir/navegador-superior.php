<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="../index.php">
      <h1>BIENVENIDO</h1>
    </a>
  </div>
  <div class="navbar-end">
    <div class="navbar-item">
      <div class="buttons">
        <a class="button is-primary" href="registrarse-vista.php">
          <strong>Registrarse</strong>
        </a>
        <a class="button is-light" href="iniciarSesion-vista.php">
          Iniciar Sesión
        </a>
      </div>
    </div>
  </div>
</nav>
