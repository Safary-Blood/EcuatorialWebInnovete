<link rel="stylesheet" href="../css/bulma.min.css">
<link rel="stylesheet" href="../css/sweetalert2.css">
