<!DOCTYPE html>
<html>
<head>
    <title>Of</title>
    <link rel="stylesheet" href="css/bulma.min.css">
</head>
<body>
    <?php include 'incluir/navegador-superior.php'; ?>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/sweetalert2.js"></script>
</body>
</html>
