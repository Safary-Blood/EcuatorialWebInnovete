<?php
class Conexion {
    private static $instancia = null;
    private $conexion;
    private $host = 'localhost:1111';
    private $usuario = 'root';
    private $contraseña = '';
    private $baseDeDatos = 'ApiWebEmpleoGuineaEcuatorial';

    private function __construct() {
        $this->conectar();
    }

    public static function getInstancia() {
        if (self::$instancia === null) {
            self::$instancia = new self();
        }
        return self::$instancia;
    }

    private function conectar() {
        $this->conexion = new mysqli($this->host, $this->usuario, $this->contraseña, $this->baseDeDatos);

        if ($this->conexion->connect_error) {
            throw new Exception("Conexión fallida: " . $this->conexion->connect_error);
        }
    }

    public function getConexion() {
        return $this->conexion;
    }

    public function cerrarConexion() {
        if ($this->conexion) {
            $this->conexion->close();
        }
    }
}

