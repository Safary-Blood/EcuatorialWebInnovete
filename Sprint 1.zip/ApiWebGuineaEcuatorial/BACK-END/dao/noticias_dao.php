<?php
require_once 'conexion.php';

class NoticiasDAO {
    private $conexion;

    public function __construct() {
        $this->conexion = Conexion::getInstancia()->getConexion();
    }

    public function obtenerNoticias() {
        $sentencia = "SELECT * FROM noticias";
        $resultado = $this->conexion->query($sentencia);
        $noticias = [];

        while ($fila = $resultado->fetch_assoc()) {
            $noticia = new Noticia($fila['titulo'], $fila['contenido'], $fila['fechaPublicacion'], $fila['idAdministrador'], $fila['foto']);
            $noticia->setIdNoticia($fila['idNoticia']);
            $noticias[] = $noticia;
        }

        return $noticias;
    }

    public function agregarNoticia($noticia) {
        $sentencia = "INSERT INTO noticias (titulo, contenido, fechaPublicacion, idAdministrador, foto) VALUES (?, ?, ?, ?, ?)";
        $estado = $this->conexion->prepare($sentencia);
        $estado->bind_param("sssis", 
            $noticia->getTitulo(), 
            $noticia->getContenido(), 
            $noticia->getFechaPublicacion(), 
            $noticia->getIdAdministrador(), 
            $noticia->getFoto()
        );

        $estado->execute();
    }

    public function obtenerNoticiaPorId($idNoticia) {
        $sentencia = "SELECT * FROM noticias WHERE idNoticia = ?";
        $estado = $this->conexion->prepare($sentencia);
        $estado->bind_param("i", $idNoticia);
        $estado->execute();
        $resultado = $estado->get_result();
        $fila = $resultado->fetch_assoc();

        if ($fila) {
            $noticia = new Noticia($fila['titulo'], $fila['contenido'], $fila['fechaPublicacion'], $fila['idAdministrador'], $fila['foto']);
            $noticia->setIdNoticia($fila['idNoticia']);
            return $noticia;
        }

        return null;
    }

    public function actualizarNoticia($noticia) {
        $sentencia = "UPDATE noticias SET titulo = ?, contenido = ?, fechaPublicacion = ?, idAdministrador = ?, foto = ? WHERE idNoticia = ?";
        $estado = $this->conexion->prepare($sentencia);
        $estado->bind_param("sssisi", 
            $noticia->getTitulo(), 
            $noticia->getContenido(), 
            $noticia->getFechaPublicacion(), 
            $noticia->getIdAdministrador(), 
            $noticia->getFoto(),
            $noticia->getIdNoticia()
        );

        $estado->execute();
    }

    public function eliminarNoticia($idNoticia) {
        $sentencia = "DELETE FROM noticias WHERE idNoticia = ?";
        $estado = $this->conexion->prepare($sentencia);
        $estado->bind_param("i", $idNoticia);
        $estado->execute();
    }
}

