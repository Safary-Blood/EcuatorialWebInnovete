<?php
require_once 'modelo/noticias_modelo.php';
require_once 'dao/noticias_dao.php';

class NoticiasAdminControlador {
    private $noticiasDAO;

    public function __construct() {
        $this->noticiasDAO = new NoticiasDAO();
    }

    public function listarNoticias() {
        $noticias = $this->noticiasDAO->obtenerNoticias();
        require 'vista/php/administrador_vista.php';
    }

    public function agregarNoticia($titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto) {
        $noticia = new Noticia($titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto);
        $this->noticiasDAO->agregarNoticia($noticia);
    }

    public function verNoticia($idNoticia) {
        $noticia = $this->noticiasDAO->obtenerNoticiaPorId($idNoticia);
        require 'vista/php/noticia_detalle_vista.php';
    }

    public function editarNoticia($idNoticia, $titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto) {
        $noticia = $this->noticiasDAO->obtenerNoticiaPorId($idNoticia);
        $noticia->setTitulo($titulo);
        $noticia->setContenido($contenido);
        $noticia->setFechaPublicacion($fechaPublicacion);
        $noticia->setIdAdministrador($idAdministrador);
        $noticia->setFoto($foto);
        $this->noticiasDAO->actualizarNoticia($noticia);
    }

    public function eliminarNoticia($idNoticia) {
        $this->noticiasDAO->eliminarNoticia($idNoticia);
    }
}

// Manejo de las acciones desde el formulario
$controlador = new NoticiasAdminControlador();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'];
    $idNoticia = isset($_POST['idNoticia']) ? $_POST['idNoticia'] : null;
    $titulo = isset($_POST['titulo']) ? $_POST['titulo'] : null;
    $contenido = isset($_POST['contenido']) ? $_POST['contenido'] : null;
    $fechaPublicacion = isset($_POST['fechaPublicacion']) ? $_POST['fechaPublicacion'] : null;
    $idAdministrador = isset($_POST['idAdministrador']) ? $_POST['idAdministrador'] : null;
    $foto = isset($_FILES['foto']) && $_FILES['foto']['size'] > 0 ? file_get_contents($_FILES['foto']['tmp_name']) : null;

    switch ($accion) {
        case 'agregar':
            $controlador->agregarNoticia($titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto);
            break;
        case 'editar':
            $controlador->editarNoticia($idNoticia, $titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto);
            break;
        case 'eliminar':
            $controlador->eliminarNoticia($idNoticia);
            break;
        case 'ver':
            $controlador->verNoticia($idNoticia);
            break;
    }
}

$controlador->listarNoticias();

