<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="footer.css">
    <title>Footer Dinámico</title>
</head>
<body>

<!-- Contenido de la página -->

<!-- Contenedor del footer -->
<div id="footer-container"></div>

<script src="footer_ajax.js"></script>
</body>
</html>
