<?php

class Notificacion {
    private $idNotificacion; // INT
    private $idUsuario; // INT
    private $mensaje; // TEXT
    private $fechaEnvio; // DATETIME
    private $estado; // ENUM('pendiente', 'enviada', 'leida')

    public function __construct($idUsuario, $mensaje, $fechaEnvio, $estado) {
        $this->idUsuario = $idUsuario;
        $this->mensaje = $mensaje;
        $this->fechaEnvio = $fechaEnvio;
        $this->estado = $estado;
    }

    // Getters y Setters
    public function getIdNotificacion() {
        return $this->idNotificacion;
    }

    public function setIdNotificacion($idNotificacion) {
        $this->idNotificacion = $idNotificacion;
    }

    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function getFechaEnvio() {
        return $this->fechaEnvio;
    }

    public function setFechaEnvio($fechaEnvio) {
        $this->fechaEnvio = $fechaEnvio;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }
}
?>
