<?php

class Empleo {
    private $idEmpleo; // INT
    private $idEmpleador; // INT
    private $titulo; // VARCHAR(100)
    private $descripcion; // TEXT
    private $fechaPublicacion; // DATE
    private $fechaCierre; // DATE
    private $ciudad; // VARCHAR(100)
    private $foto; // BLOB

    public function __construct($idEmpleador, $titulo, $descripcion, $fechaPublicacion, $fechaCierre, $ciudad, $foto) {
        $this->idEmpleador = $idEmpleador;
        $this->titulo = $titulo;
        $this->descripcion = $descripcion;
        $this->fechaPublicacion = $fechaPublicacion;
        $this->fechaCierre = $fechaCierre;
        $this->ciudad = $ciudad;
        $this->foto = $foto;
    }

    // Getters y Setters
    public function getIdEmpleo() {
        return $this->idEmpleo;
    }

    public function setIdEmpleo($idEmpleo) {
        $this->idEmpleo = $idEmpleo;
    }

    public function getIdEmpleador() {
        return $this->idEmpleador;
    }

    public function setIdEmpleador($idEmpleador) {
        $this->idEmpleador = $idEmpleador;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function getFechaPublicacion() {
        return $this->fechaPublicacion;
    }

    public function setFechaPublicacion($fechaPublicacion) {
        $this->fechaPublicacion = $fechaPublicacion;
    }

    public function getFechaCierre() {
        return $this->fechaCierre;
    }

    public function setFechaCierre($fechaCierre) {
        $this->fechaCierre = $fechaCierre;
    }

    public function getCiudad() {
        return $this->ciudad;
    }

    public function setCiudad($ciudad) {
        $this->ciudad = $ciudad;
    }

    public function getFoto() {
        return $this->foto;
    }

    public function setFoto($foto) {
        $this->foto = $foto;
    }
}
?>
