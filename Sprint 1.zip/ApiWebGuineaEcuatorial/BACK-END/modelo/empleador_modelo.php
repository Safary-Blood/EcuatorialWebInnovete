<?php

class Empleador {
    private $idEmpleador; // INT
    private $idUsuario; // INT
    private $nombre; // VARCHAR(100)
    private $apellidos; // VARCHAR(100)
    private $fechaNacimiento; // DATE
    private $telefono; // VARCHAR(20)
    private $direccion; // VARCHAR(255)
    private $empresa; // VARCHAR(255)
    private $logo; // BLOB
    private $foto; // BLOB

    public function __construct($idUsuario, $nombre, $apellidos, $fechaNacimiento, $telefono, $direccion, $empresa, $logo, $foto) {
        $this->idUsuario = $idUsuario;
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->fechaNacimiento = $fechaNacimiento;
        $this->telefono = $telefono;
        $this->direccion = $direccion;
        $this->empresa = $empresa;
        $this->logo = $logo;
        $this->foto = $foto;
    }

    // Getters y Setters
    public function getIdEmpleador() {
        return $this->idEmpleador;
    }

    public function setIdEmpleador($idEmpleador) {
        $this->idEmpleador = $idEmpleador;
    }

    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getApellidos() {
        return $this->apellidos;
    }

    public function setApellidos($apellidos) {
        $this->apellidos = $apellidos;
    }

    public function getFechaNacimiento() {
        return $this->fechaNacimiento;
    }

    public function setFechaNacimiento($fechaNacimiento) {
        $this->fechaNacimiento = $fechaNacimiento;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function getDireccion() {
        return $this->direccion;
    }

    public function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    public function getEmpresa() {
        return $this->empresa;
    }

    public function setEmpresa($empresa) {
        $this->empresa = $empresa;
    }

    public function getLogo() {
        return $this->logo;
    }

    public function setLogo($logo) {
        $this->logo = $logo;
    }

    public function getFoto() {
        return $this->foto;
    }

    public function setFoto($foto) {
        $this->foto = $foto;
    }
}
?>
