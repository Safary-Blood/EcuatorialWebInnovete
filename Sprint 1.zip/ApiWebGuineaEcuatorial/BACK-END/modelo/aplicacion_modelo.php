<?php

class Aplicacion {
    private $idAplicacion; // INT
    private $idEmpleo; // INT
    private $idCandidato; // INT
    private $fechaAplicacion; // DATE
    private $estado; // ENUM('enviada', 'en revisión', 'aceptada', 'rechazada')

    public function __construct($idEmpleo, $idCandidato, $fechaAplicacion, $estado) {
        $this->idEmpleo = $idEmpleo;
        $this->idCandidato = $idCandidato;
        $this->fechaAplicacion = $fechaAplicacion;
        $this->estado = $estado;
    }

    // Getters y Setters
    public function getIdAplicacion() {
        return $this->idAplicacion;
    }

    public function setIdAplicacion($idAplicacion) {
        $this->idAplicacion = $idAplicacion;
    }

    public function getIdEmpleo() {
        return $this->idEmpleo;
    }

    public function setIdEmpleo($idEmpleo) {
        $this->idEmpleo = $idEmpleo;
    }

    public function getIdCandidato() {
        return $this->idCandidato;
    }

    public function setIdCandidato($idCandidato) {
        $this->idCandidato = $idCandidato;
    }

    public function getFechaAplicacion() {
        return $this->fechaAplicacion;
    }

    public function setFechaAplicacion($fechaAplicacion) {
        $this->fechaAplicacion = $fechaAplicacion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }
}
?>
