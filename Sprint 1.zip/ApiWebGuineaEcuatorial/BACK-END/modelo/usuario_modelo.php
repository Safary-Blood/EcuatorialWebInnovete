<?php

class Usuario {
    private $idUsuario; // INT
    private $nombre; // VARCHAR(100)
    private $email; // VARCHAR(100)
    private $contrasena; // VARCHAR(255)
    private $rol; // ENUM('administrador', 'empleador', 'candidato')

    public function __construct($nombre, $email, $contrasena, $rol) {
        $this->nombre = $nombre;
        $this->email = $email;
        $this->contrasena = $contrasena;
        $this->rol = $rol;
    }

    // Getters y Setters
    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getContrasena() {
        return $this->contrasena;
    }

    public function setContrasena($contrasena) {
        $this->contrasena = $contrasena;
    }

    public function getRol() {
        return $this->rol;
    }

    public function setRol($rol) {
        $this->rol = $rol;
    }
}
?>
