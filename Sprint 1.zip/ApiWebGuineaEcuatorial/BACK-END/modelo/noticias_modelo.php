<?php

class Noticia {
    private $idNoticia; // INT
    private $titulo; // VARCHAR(255)
    private $contenido; // TEXT
    private $fechaPublicacion; // DATE
    private $idAdministrador; // INT
    private $foto; // BLOB

    public function __construct($titulo, $contenido, $fechaPublicacion, $idAdministrador, $foto) {
        $this->titulo = $titulo;
        $this->contenido = $contenido;
        $this->fechaPublicacion = $fechaPublicacion;
        $this->idAdministrador = $idAdministrador;
        $this->foto = $foto;
    }

    // Getters y Setters
    public function getIdNoticia() {
        return $this->idNoticia;
    }

    public function setIdNoticia($idNoticia) {
        $this->idNoticia = $idNoticia;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getContenido() {
        return $this->contenido;
    }

    public function setContenido($contenido) {
        $this->contenido = $contenido;
    }

    public function getFechaPublicacion() {
        return $this->fechaPublicacion;
    }

    public function setFechaPublicacion($fechaPublicacion) {
        $this->fechaPublicacion = $fechaPublicacion;
    }

    public function getIdAdministrador() {
        return $this->idAdministrador;
    }

    public function setIdAdministrador($idAdministrador) {
        $this->idAdministrador = $idAdministrador;
    }

    public function getFoto() {
        return $this->foto;
    }

    public function setFoto($foto) {
        $this->foto = $foto;
    }
}
?>
