<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Noticia</title>
</head>
<body>
    <h1><?php echo $noticia->getTitulo(); ?></h1>
    <p><?php echo $noticia->getContenido(); ?></p>
    <p><strong>Fecha de Publicación:</strong> <?php echo $noticia->getFechaPublicacion(); ?></p>
    <p><strong>ID del Administrador:</strong> <?php echo $noticia->getIdAdministrador(); ?></p>
    <?php if ($noticia->getFoto()): ?>
        <p><img src="data:image/jpeg;base64,<?php echo base64_encode($noticia->getFoto()); ?>" alt="Foto de la Noticia" style="max-width: 200px;"></p>
    <?php endif; ?>
    <a href="administrador_vista.php">Volver a la lista de noticias</a>
</body>
</html>
