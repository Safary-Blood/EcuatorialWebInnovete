<?php
// footer.php
?>

<div class="contenedor">
    <div class="fila">
        <div class="columna" id="contacto">
            <h3>Contacto</h3>
            <ul>
                <li>+240222783964</li>
                <li>+240222401186</li>
                <li>+240222721409</li>
            </ul>
            <p>Empresa: Potential Proyect</p>
        </div>
        <div class="columna" id="enlaces">
            <h3>Enlaces</h3>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="nosotros.php">Nosotros</a></li>
                <li><a href="ayuda.php">Ayuda</a></li>
                <li><a href="terminos.php">Términos y Condiciones</a></li>
            </ul>
        </div>
        <div class="columna" id="redes-sociales">
            <h3>Redes Sociales</h3>
            <ul>
                <li><a href="https://wa.link/4vggfl" target="_blank">WhatsApp</a></li>
            </ul>
        </div>
    </div>
    <div class="fila">
        <div class="columna" id="mapa-del-sitio">
            <h3>Mapa del Sitio</h3>
            <p>Estamos en Guinea Ecuatorial en la región continental, concretamente en la ciudad de Djibloho en la Universidad Afroamericana de África Central.</p>
            <a href="https://maps.app.goo.gl/mW1QAefnP1pp83aM9" target="_blank">Ver mapa</a>
        </div>
    </div>
    <div class="fila">
        <div class="columna" id="derechos-de-autor">
            <p>Derechos de autor: Ecuatorial Web Innovate (EWI)</p>
        </div>
    </div>
    <div class="fila">
        <div class="columna" id="boton-volver-arriba">
            <!-- Botón de retorno arriba -->
            <a href="#pie-de-pagina" class="boton-volver-arriba">Volver arriba</a>
        </div>
    </div>
</div>
