<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador de Noticias</title>
    <style>
        /* Aquí puedes agregar estilos CSS para mejorar la presentación */
        .noticia-form, .noticias-lista {
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
        }

        .noticia-item {
            border-bottom: 1px solid #ccc;
            margin-bottom: 10px;
            padding-bottom: 10px;
        }

        .noticia-item:last-child {
            border-bottom: none;
        }

        .noticia-item h3 {
            margin: 0;
        }
    </style>
</head>
<body>
    <h1>Administrador de Noticias</h1>

    <!-- Sección para el formulario de agregar/editar noticia -->
    <div class="noticia-form">
        <h2><?php echo isset($noticia) ? 'Editar Noticia' : 'Agregar Noticia'; ?></h2>
        <form action="noticias_admin_controlador.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="idNoticia" value="<?php echo isset($noticia) ? $noticia->getIdNoticia() : ''; ?>">

            <label for="titulo">Título:</label>
            <input type="text" name="titulo" id="titulo" value="<?php echo isset($noticia) ? $noticia->getTitulo() : ''; ?>" required>

            <label for="contenido">Contenido:</label>
            <textarea name="contenido" id="contenido" required><?php echo isset($noticia) ? $noticia->getContenido() : ''; ?></textarea>

            <label for="fechaPublicacion">Fecha de Publicación:</label>
            <input type="date" name="fechaPublicacion" id="fechaPublicacion" value="<?php echo isset($noticia) ? $noticia->getFechaPublicacion() : ''; ?>" required>

            <label for="idAdministrador">ID del Administrador:</label>
            <input type="number" name="idAdministrador" id="idAdministrador" value="<?php echo isset($noticia) ? $noticia->getIdAdministrador() : ''; ?>" required>

            <label for="foto">Foto:</label>
            <input type="file" name="foto" id="foto" <?php echo isset($noticia) ? '' : 'required'; ?>>

            <button type="submit" name="accion" value="<?php echo isset($noticia) ? 'editar' : 'agregar'; ?>">
                <?php echo isset($noticia) ? 'Editar' : 'Agregar'; ?>
            </button>
        </form>
    </div>

    <!-- Sección para la lista de noticias publicadas -->
    <div class="noticias-lista">
        <h2>Lista de Noticias Publicadas</h2>
        <?php foreach ($noticias as $noticia): ?>
            <div class="noticia-item">
                <h3><?php echo $noticia->getTitulo(); ?></h3>
                <p><?php echo $noticia->getContenido(); ?></p>
                <p><strong>Fecha de Publicación:</strong> <?php echo $noticia->getFechaPublicacion(); ?></p>
                <p><strong>ID del Administrador:</strong> <?php echo $noticia->getIdAdministrador(); ?></p>
                <?php if ($noticia->getFoto()): ?>
                    <p><img src="data:image/jpeg;base64,<?php echo base64_encode($noticia->getFoto()); ?>" alt="Foto de la Noticia" style="max-width: 200px;"></p>
                <?php endif; ?>
                <form action="noticias_admin_controlador.php" method="POST" style="display:inline;">
                    <input type="hidden" name="idNoticia" value="<?php echo $noticia->getIdNoticia(); ?>">
                    <button type="submit" name="accion" value="ver">Ver</button>
                    <button type="submit" name="accion" value="editar">Editar</button>
                    <button type="submit" name="accion" value="eliminar">Eliminar</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
