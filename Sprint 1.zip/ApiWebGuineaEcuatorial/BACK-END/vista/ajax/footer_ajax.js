document.addEventListener("DOMContentLoaded", function() {
    // Cargar el contenido del footer de forma dinámica
    const footerContainer = document.getElementById('footer-container');
    fetch('footer.php')
        .then(response => response.text())
        .then(data => {
            footerContainer.innerHTML = data;

            // Animación al cargar el footer
            const footer = footerContainer.querySelector(".contenedor");
            if (footer) {
                footer.style.opacity = 1;
                footer.style.transform = "translateY(0)";
            }

            // Botón de retorno arriba
            const btnVolverArriba = footerContainer.querySelector(".boton-volver-arriba");
            btnVolverArriba.addEventListener("click", function(event) {
                event.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });
            });

            // Mostrar botón de retorno arriba al hacer scroll
            window.addEventListener("scroll", function() {
                if (window.scrollY > 300) {
                    btnVolverArriba.style.display = "block";
                } else {
                    btnVolverArriba.style.display = "none";
                }
            });
        })
        .catch(error => console.error('Error al cargar el footer:', error));
});
