      //Obtener el botón
      let mybutton = document.getElementById("myBtn");

      // Cuando el usuario se desplaza hacia abajo 20px desde la parte superior del documento, muestra el botón
      window.onscroll = function() {scrollFunction()};

      function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          mybutton.style.display = "block";
        } else {
          mybutton.style.display = "none";
        }
      }

      // Cuando el usuario hace clic en el botón, se desplaza hacia la parte superior del documento
      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }